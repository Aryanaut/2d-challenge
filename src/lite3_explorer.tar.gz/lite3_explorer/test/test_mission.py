"""Mission manager logic in a simulated corridor (no ROS): modes, stuck recovery and end conditions."""
import math

import numpy as np
import pytest

from lite3_explorer.map_grid import GridInfo
from lite3_explorer.mission.config import DEFAULTS, merge_flat
from lite3_explorer.mission.core import ModeMachine
from lite3_explorer.mission.end_conditions import MissionSnapshot, build_end_condition
from lite3_explorer.mission.stuck import StuckDetector
from lite3_explorer.mission.traversal import FAILED, RUNNING, SUCCEEDED, Traversal, TraversalResult
from lite3_explorer.tile_tracker import TileTracker

RES = 0.05


def room(w_m, h_m):
    return corridor(w_m, h_m)


def corridor(length_m=4.0, width_m=1.0):
    """A fully mapped 1 m wide corridor from x=0 to x=length_m, walls one cell thick around it."""
    margin = 1.0
    info = GridInfo(int((length_m + 2 * margin) / RES), int((width_m + 2 * margin) / RES), RES, -margin, -margin)
    grid = np.full((info.height, info.width), -1, dtype=np.int16)
    r0, c0 = info.world_to_cell(0.0, 0.0)
    r1, c1 = info.world_to_cell(length_m, width_m)
    grid[r0 - 1:r1 + 1, c0 - 1:c1 + 1] = 100
    grid[r0:r1, c0:c1] = 0
    return grid, info


class FakeScanner:
    ready = True

    def __init__(self):
        self.turns = []

    def __init__(self, ctx=None):
        self.turns, self.ctx = [], ctx

    def start(self, deg, allowance):
        self.turns.append(deg)
        if self.ctx is not None:
            self.ctx.reveal()

    def poll(self):
        return SUCCEEDED

    def cancel(self):
        pass

    def has_room(self):
        return True


class FakePaths:
    def __init__(self, ctx):
        self.ctx, self.goals = ctx, None

    def start(self, goals):
        self.goals = goals
        return True

    def poll(self):
        out = []
        for g in self.goals:
            label = '%d,%d' % self.ctx.tiles.tile_of(*g)
            out.append(None if label in self.ctx.no_path else [tuple(self.ctx.pose_[:2]), tuple(g)])
        return out

    def cancel(self):
        pass


class FakeTraversal(Traversal):
    uses_route = True

    def available(self):
        return self.ctx.nav_up

    def start(self, goal_xy, yaw, route=None):
        self.goal, self.started, self.cancelled = goal_xy, self.ctx.t, False
        self.ctx.drives.append((self.name, '%d,%d' % self.ctx.tiles.tile_of(*goal_xy)))
        return True

    def poll(self):
        label = '%d,%d' % self.ctx.tiles.tile_of(*self.goal)
        if label in self.ctx.stuck_tiles:
            return TraversalResult(RUNNING)          # never arrives, never moves
        if label in self.ctx.fail_tiles:
            return TraversalResult(FAILED, 'aborted by Nav2')
        if self.ctx.t - self.started >= 2:
            self.ctx.pose_ = [self.goal[0], self.goal[1], 0.0]
            return TraversalResult(SUCCEEDED)
        return TraversalResult(RUNNING)

    def cancel(self):
        self.cancelled = True


class FakeCtx:
    def __init__(self, cfg, pose=(0.5, 0.5, 0.0), length_m=4.0, world=None, reveal_m=None):
        self.cfg = cfg
        self.t = 0.0
        self.pose_ = list(pose)
        self.truth, self.info = world if world is not None else corridor(length_m)
        self.reveal_m = reveal_m              # None: the whole map is known from the start
        self.tiles = TileTracker(max_failures=cfg['tiles']['max_failures'])
        if reveal_m is None:
            self.tiles.set_map(self.truth, self.info)
        else:
            self.known = np.full_like(self.truth, -1)
            self.reveal()
        self.scanner, self.paths = FakeScanner(self), FakePaths(self)
        self.events, self.logs, self.drives = [], [], []
        self.complete, self.cost, self.cleared = None, 0, 0
        self.stuck_tiles, self.fail_tiles, self.no_path = set(), set(), set()
        self.nav_up = True

    def now(self):
        return self.t

    def reveal(self):
        """Fake lidar: copy the true map within reveal_m of the robot into the known map."""
        if self.reveal_m is None:
            return
        info = self.info
        rows, cols = np.mgrid[0:info.height, 0:info.width]
        xs = info.origin_x + (cols + 0.5) * info.resolution
        ys = info.origin_y + (rows + 0.5) * info.resolution
        near = np.hypot(xs - self.pose_[0], ys - self.pose_[1]) <= self.reveal_m
        self.known[near] = self.truth[near]
        self.tiles.set_map(self.known.copy(), info)

    def log(self, level, msg):
        self.logs.append((level, msg))

    def pose(self):
        return list(self.pose_)

    def local_map_ready(self, pose):
        return True

    def ready_for_start(self):
        return True, []

    def gait_hold(self, kind):
        pass

    def traversal(self, name):
        if name not in self.cfg['traversals']:
            raise KeyError(name)
        return FakeTraversal(self, name, self.cfg['traversals'][name])

    def costmap_cost_at_robot(self):
        return self.cost

    def clear_costmaps(self):
        self.cleared += 1

    def set_target(self, label, goal_xy, route):
        pass

    def event(self, kind, **data):
        self.events.append((kind, data))

    def on_mode_change(self, mode, phase):
        pass

    def on_complete(self, reason):
        self.complete = reason


def run(ctx, machine, steps=400, until_complete=True):
    for _ in range(steps):
        ctx.t += 1.0
        machine.tick()
        ctx.tiles.track(ctx.pose_)
        if until_complete and ctx.complete:
            break


def make(flat=None, **ctx_kw):
    cfg = merge_flat(DEFAULTS, flat or {})
    ctx = FakeCtx(cfg, **ctx_kw)
    m = ModeMachine(ctx, cfg)
    m.start()
    return ctx, m


def modes_seen(m):
    return [t[2] for t in m.transitions]


# ------------------------------------------------------------------------------------------------ tests
def test_explores_every_tile_then_completes():
    ctx, m = make()
    run(ctx, m)
    assert ctx.complete and ctx.complete.startswith('all_tiles_explored')
    assert ctx.tiles.unexplored() == []
    assert ctx.tiles.visited_count() == 4
    seen = modes_seen(m)
    assert seen[:3] == ['idle', 'scanning', 'exploring'] and seen[-1] == 'complete'
    assert 'recovery' not in seen
    assert ctx.scanner.turns[:2] == [-90.0, 180.0]            # opening sweep first, then full turns
    assert 360.0 in ctx.scanner.turns
    assert all(name == 'route' for name, _ in ctx.drives)


def test_stuck_without_motion_goes_to_nearest_tile_centre_then_gives_up_on_the_tile():
    ctx, m = make({'tiles.max_failures': 2, 'stuck.window_s': 5.0, 'stuck.cooldown_s': 0.0})
    ctx.stuck_tiles = {'2,0'}
    run(ctx, m, steps=600)
    seen = modes_seen(m)
    assert 'recovery' in seen
    stuck = [d for k, d in ctx.events if k == 'stuck']
    assert stuck and stuck[0]['target'] == '2,0' and 'moved only' in stuck[0]['why']
    # recovery drives to a tile centre with the 'direct' profile, never the tile it got stuck on
    rec = [tile for name, tile in ctx.drives if name == 'direct']
    assert rec and '2,0' not in rec
    assert ctx.cleared >= 1
    assert '2,0' in ctx.tiles.unreachable
    assert ctx.complete and 'unreachable skipped' in ctx.complete


def test_costmap_trigger():
    ctx, m = make({'stuck.triggers': ['costmap'], 'stuck.costmap_hold_s': 2.0, 'stuck.cooldown_s': 0.0})
    run(ctx, m, steps=6, until_complete=False)
    assert m.current.name == 'exploring'
    ctx.cost = 100
    run(ctx, m, steps=4, until_complete=False)
    assert 'recovery' in modes_seen(m)
    assert any(k == 'stuck' and 'costmap' in d['why'] for k, d in ctx.events)


def test_no_path_to_any_tile_recovers_and_finally_gives_up():
    ctx, m = make({'modes.recovery.give_up_after': 2})
    ctx.no_path = {'1,0', '2,0', '3,0'}
    run(ctx, m, steps=300)
    assert modes_seen(m).count('recovery') >= 2
    assert ctx.tiles.unexplored() == []
    assert ctx.tiles.unreachable                          # given up on after the recoveries
    assert ctx.complete


def test_failed_goal_chooses_another_tile_and_marks_unreachable():
    ctx, m = make({'tiles.max_failures': 1})
    ctx.fail_tiles = {'1,0'}
    run(ctx, m, steps=200)
    assert '1,0' in ctx.tiles.unreachable
    assert ctx.complete


def test_time_limit_end_condition():
    ctx, m = make({'end_condition.conditions': ['all_tiles_explored', 'time_limit'],
                   'end_condition.time_limit.seconds': 5.0})
    ctx.stuck_tiles = {'1,0'}
    run(ctx, m, steps=50)
    assert ctx.complete and ctx.complete.startswith('time_limit')


def test_combine_all_needs_every_condition():
    cond = build_end_condition({'combine': 'all', 'conditions': ['all_tiles_explored', 'max_tiles_visited'],
                                'all_tiles_explored': {'min_visited': 1}, 'max_tiles_visited': {'count': 3}})
    snap = MissionSnapshot({}, visited=2, unexplored=[])
    assert cond.check(snap, checkpoint=True) is None
    snap.visited = 3
    assert cond.check(snap, checkpoint=True)


def test_checkpoint_conditions_only_change_at_checkpoints():
    cond = build_end_condition({'conditions': ['all_tiles_explored']})
    assert cond.check(MissionSnapshot({}, visited=3, unexplored=[]), checkpoint=False) is None
    assert cond.check(MissionSnapshot({}, visited=3, unexplored=[]), checkpoint=True)


def test_unknown_end_condition_and_mode_are_rejected():
    with pytest.raises(ValueError):
        build_end_condition({'conditions': ['nope']})
    cfg = merge_flat(DEFAULTS, {'modes.exploring.scan_mode': 'look_around'})
    with pytest.raises(ValueError, match='look_around'):
        ModeMachine(FakeCtx(cfg), cfg)


def test_custom_mode_instance_and_traversal_profile_from_config():
    ctx, m = make({'mission.modes': ['idle', 'scanning', 'explore_direct', 'recovery', 'complete'],
                   'modes.scanning.next_mode': 'explore_direct',
                   'modes.explore_direct.type': 'exploring',
                   'modes.explore_direct.traversal': 'careful',
                   'modes.explore_direct.tile_traversals': ['3,0:direct'],
                   'traversals.careful.type': 'nav2_pose'})
    run(ctx, m)
    assert ctx.complete
    names = {tile: name for name, tile in ctx.drives}
    assert names['1,0'] == 'careful' and names['3,0'] == 'direct'


def test_pause_and_resume():
    ctx, m = make()
    run(ctx, m, steps=6, until_complete=False)
    assert m.activate(False) == 'idle'
    run(ctx, m, steps=10, until_complete=False)
    assert m.current.name == 'idle' and m.current.phase == 'paused'
    m.activate(True)
    assert m.current.name == 'scanning'
    run(ctx, m)
    assert ctx.complete


def test_stuck_detector_no_motion():
    d = StuckDetector(['no_motion'], window_s=5.0, min_motion_m=0.2)
    for t in range(5):
        assert d.update(float(t), (0.0, 0.0), driving=True) is None
    assert d.update(5.0, (0.05, 0.0), driving=True)
    d.reset()
    for t in range(10):
        assert d.update(float(t), (0.1 * t, 0.0), driving=True) is None     # moving: never stuck
    assert d.update(11.0, (0.0, 0.0), driving=False) is None               # not driving: never stuck


def test_stuck_detector_costmap():
    d = StuckDetector(['costmap'], costmap_cost=99, costmap_hold_s=2.0)
    assert d.update(0.0, None, False, 100) is None
    assert d.update(1.0, None, False, 50) is None          # left the zone: timer restarts
    assert d.update(2.0, None, False, 99) is None
    assert d.update(4.0, None, False, 99)
    with pytest.raises(ValueError):
        StuckDetector(['bogus'])


def test_recovery_targets_are_tile_centres_nearest_first():
    ctx, _ = make()
    ctx.tiles.establish([1.5, 0.5, 0.0])
    label = lambda x: '%d,%d' % ctx.tiles.tile_of(x, 0.5)  # noqa: E731
    near = ctx.tiles.recovery_targets([1.4, 0.5], min_distance_m=0.0)
    assert [t['tile'] for t in near][:3] == [label(1.5), label(0.5), label(2.5)]
    first = ctx.tiles.recovery_targets([1.4, 0.5], min_distance_m=0.25)[0]
    assert first['tile'] == label(0.5)                                   # the robot's own centre is skipped
    assert math.dist(first['goal_xy'], first['centre_xy']) < 0.1          # the centre itself in a clear corridor
    assert ctx.tiles.recovery_targets([1.4, 0.5], exclude=[label(0.5)])[0]['tile'] == label(2.5)


def test_merge_flat_drops_empty_string_lists():
    cfg = merge_flat(DEFAULTS, {'modes.exploring.tile_traversals': [''], 'stuck.window_s': 9.0})
    assert cfg['modes']['exploring']['tile_traversals'] == []
    assert cfg['stuck']['window_s'] == 9.0
    assert DEFAULTS['stuck']['window_s'] == 20.0


def test_waits_for_nav2_instead_of_giving_up_on_tiles():
    ctx, m = make()
    ctx.nav_up = False
    run(ctx, m, steps=60, until_complete=False)
    assert m.current.name == 'exploring' and m.current.phase in ('wait_traversal', 'decide', 'checking_paths')
    assert not ctx.tiles.unreachable and not ctx.complete
    ctx.nav_up = True
    run(ctx, m)
    assert ctx.complete and not ctx.tiles.unreachable



# ------------------------------------------------------------------------- exploration strategies
def targets_chosen(ctx):
    return [d for k, d in ctx.events if k == 'target']


def test_next_tile_shares_a_side_with_an_explored_tile():
    # 3 m x 2 m open room: from tile 0,0 the diagonal 1,1 is never chosen before one of its side neighbours
    ctx, m = make(world=room(3.0, 2.0))
    run(ctx, m)
    assert ctx.complete and ctx.tiles.unexplored() == []
    chosen = targets_chosen(ctx)
    assert len(chosen) == 5 and all(t['adjacency'] in (0, 1, 2) for t in chosen)
    assert chosen[0]['adjacency'] == 0                    # first pick: a neighbour of the current tile


def test_adjacency_levels_rank_the_current_tiles_neighbours_first():
    ctx, m = make(world=room(3.0, 2.0))
    run(ctx, m)
    # with prefer_current every pick is a neighbour of the tile the robot stands on (the room is open)
    assert all(t['adjacency'] == 0 for t in targets_chosen(ctx))


def test_unreachable_tiles_are_eliminated_after_strikes():
    ctx, m = make({'explorations.tiles.eliminate_after': 2, 'explorations.tiles.max_adjacency': 3},
                  world=room(3.0, 2.0))
    ctx.no_path = {'2,1'}
    run(ctx, m)
    assert '2,1' in ctx.tiles.unreachable and 'no Nav2 path' in ctx.tiles.unreachable['2,1']
    assert any(k == 'eliminated' and d['tiles'] == ['2,1'] for k, d in ctx.events)
    assert 'recovery' not in modes_seen(m)                # other tiles stayed reachable: no recovery needed
    assert ctx.complete and 'unreachable skipped' in ctx.complete


def test_all_paths_failing_eliminates_nothing_and_recovers():
    ctx, m = make({'modes.recovery.give_up_after': 0})
    run(ctx, m, steps=6, until_complete=False)
    ctx.no_path = {'1,0', '2,0', '3,0'}
    ctx.stuck_tiles = {'1,0', '2,0', '3,0'}               # and recovery can't move into them either
    run(ctx, m, steps=40, until_complete=False)
    assert 'recovery' in modes_seen(m)
    assert not any(k == 'eliminated' for k, _ in ctx.events)


def test_tiles_only_finishes_when_identified_tiles_are_done():
    # the fake lidar sees 1.2 m: the next tile is never 70 % mapped, so it is never identified
    ctx, m = make(world=corridor(6.0), reveal_m=1.2)
    run(ctx, m)
    assert ctx.complete and ctx.tiles.visited_count() < 6
    assert all(t['target_kind'] == 'tile' for t in targets_chosen(ctx))


def test_optional_frontier_fallback_opens_up_the_map():
    ctx, m = make({'modes.exploring.exploration': ['tiles', 'frontier'],
                   'end_condition.combine': 'all',
                   'end_condition.conditions': ['all_tiles_explored', 'no_frontiers_left']},
                  world=corridor(6.0), reveal_m=1.2)
    run(ctx, m, steps=800)
    kinds = [t['target_kind'] for t in targets_chosen(ctx)]
    assert 'frontier' in kinds and 'tile' in kinds
    assert ctx.complete and 'no_frontiers_left' in ctx.complete
    assert ctx.tiles.visited_count() == 6


def test_kind_traversal_override_and_bad_exploration_profile():
    ctx, m = make({'modes.exploring.exploration': ['tiles', 'frontier'],
                   'modes.exploring.kind_traversals': ['frontier:direct'],
                   'end_condition.combine': 'all',
                   'end_condition.conditions': ['all_tiles_explored', 'no_frontiers_left']},
                  world=corridor(6.0), reveal_m=1.2)
    run(ctx, m, steps=800)
    by_kind = {t['target_kind']: t['traversal'] for t in targets_chosen(ctx)}
    assert by_kind == {'tile': 'route', 'frontier': 'direct'}
    cfg = merge_flat(DEFAULTS, {'modes.exploring.exploration': ['nope']})
    with pytest.raises(KeyError, match='nope'):
        ModeMachine(FakeCtx(cfg), cfg)


def test_adjacency_fallback_when_the_link_tile_is_eliminated():
    ctx, m = make({'tiles.max_failures': 1})
    ctx.fail_tiles = {'1,0'}                              # tiles 2,0 and 3,0 only touch 1,0
    run(ctx, m)
    assert '1,0' in ctx.tiles.unreachable
    assert ctx.tiles.unexplored() == [] and ctx.complete
    assert any(t['adjacency'] == 3 for t in targets_chosen(ctx))


def test_nav2_gets_three_waypoints_then_the_exact_tile_centre():
    ctx, m = make()
    run(ctx, m)
    chosen = targets_chosen(ctx)
    assert chosen
    for t in chosen:
        route = t['route']
        assert len(route) == 4                                       # 3 intermediate waypoints + the goal
        tile = tuple(int(v) for v in t['tile'].split(','))
        cx, cy = ctx.tiles.grid.center(tile)
        assert math.dist((route[-1]['x'], route[-1]['y']), (cx, cy)) < 1e-3   # the goal IS the tile centre
    ctx, m = make({'traversals.route.waypoints': 5})
    run(ctx, m)
    assert all(len(t['route']) == 6 for t in targets_chosen(ctx))
